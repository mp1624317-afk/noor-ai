"""Pydantic schemas shared across the API."""
from __future__ import annotations

from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, Field


class SourceChunk(BaseModel):
    """A single retrieved chunk with its citation metadata."""

    chunk_id: str
    volume: int
    page: int
    chapter: str
    heading: Optional[str] = None
    excerpt: str
    score: float


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=4000)
    conversation_id: Optional[str] = None
    top_k: Optional[int] = None
    temperature: Optional[float] = None
    volume_filter: Optional[list[int]] = None
    chapter_filter: Optional[str] = None


class ChatResponse(BaseModel):
    conversation_id: str
    answer: str
    grounded: bool
    sources: list[SourceChunk]
    created_at: datetime


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str
    sources: list[SourceChunk] = Field(default_factory=list)
    created_at: datetime


class Conversation(BaseModel):
    conversation_id: str
    title: str
    messages: list[ChatMessage] = Field(default_factory=list)
    updated_at: datetime


class ReindexResponse(BaseModel):
    status: str
    documents_processed: int
    chunks_indexed: int


class SourcesResponse(BaseModel):
    volumes: list[int]
    chapters: list[str]
    total_chunks: int
