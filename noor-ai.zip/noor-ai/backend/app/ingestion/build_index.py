"""
Builds (or rebuilds) the FAISS vector index from every PDF in PDF_DIR.

Usage (from backend/ directory):
    python -m app.ingestion.build_index

This is also invoked internally by the POST /reindex API endpoint.
"""
from __future__ import annotations

import logging
from pathlib import Path

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings

from app.config import settings
from app.ingestion.pdf_processor import process_pdf

logger = logging.getLogger("noor_ai.ingestion")


def build_documents_from_pdfs(pdf_dir: Path, chunk_size: int, overlap: int) -> list[Document]:
    """Run the full ingestion pipeline over every PDF and return LangChain Documents."""
    pdf_files = sorted(pdf_dir.glob("*.pdf"))
    if not pdf_files:
        logger.warning("No PDF files found in %s", pdf_dir)

    documents: list[Document] = []
    for pdf_path in pdf_files:
        chunks = process_pdf(pdf_path, chunk_size, overlap)
        for chunk in chunks:
            documents.append(
                Document(
                    page_content=chunk.text,
                    metadata={
                        "chunk_id": chunk.chunk_id,
                        "volume": chunk.volume,
                        "page": chunk.page,
                        "chapter": chunk.chapter,
                        "heading": chunk.heading,
                        "source_file": pdf_path.name,
                    },
                )
            )
        logger.info("  -> %d chunks from %s", len(chunks), pdf_path.name)

    return documents


def build_and_save_index() -> tuple[int, int]:
    """
    Build the FAISS index from scratch and persist it to INDEX_DIR.
    Returns (documents_processed, chunks_indexed).
    """
    pdf_dir = settings.pdf_path
    index_dir = settings.index_path

    documents = build_documents_from_pdfs(
        pdf_dir, settings.chunk_size_tokens, settings.chunk_overlap_tokens
    )

    if not documents:
        logger.warning("No documents produced — index not written. Add PDFs to %s", pdf_dir)
        return 0, 0

    embeddings = OpenAIEmbeddings(
        model=settings.openai_embedding_model,
        api_key=settings.openai_api_key,
    )

    vector_store = FAISS.from_documents(documents, embeddings)
    vector_store.save_local(str(index_dir))

    num_pdfs = len({d.metadata["source_file"] for d in documents})
    logger.info("Index built: %d chunks from %d PDF(s), saved to %s", len(documents), num_pdfs, index_dir)
    return num_pdfs, len(documents)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    build_and_save_index()
