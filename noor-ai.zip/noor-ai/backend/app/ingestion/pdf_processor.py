"""
PDF ingestion pipeline for Bahaar-e-Shariat volumes.

Responsibilities:
  * Extract clean text per page using PyMuPDF
  * Strip running headers/footers and duplicate page numbers
  * Detect chapter headings using simple heuristics (bold / large-font lines,
    or explicit "CHAPTER" / numbered-heading patterns)
  * Split cleaned text into overlapping token-bounded chunks
  * Attach volume / page / chapter metadata to every chunk

The volume number is inferred from the filename. Uploaded files should be
named so the volume number appears in them, e.g.:
    bahaar-e-shariat-vol-1.pdf ... bahaar-e-shariat-vol-6.pdf
If no number is found, the volume defaults to 0 ("unknown") and a warning
is logged so it can be renamed/fixed.
"""
from __future__ import annotations

import re
import uuid
import logging
from dataclasses import dataclass, field
from pathlib import Path

import fitz  # PyMuPDF
import tiktoken

logger = logging.getLogger("noor_ai.ingestion")

_VOLUME_PATTERN = re.compile(r"vol(?:ume)?[\s._-]*(\d+)", re.IGNORECASE)
_HEADING_PATTERN = re.compile(
    r"^(chapter|kitab|bab|ruling on|masla|the\s)\b.{0,80}$", re.IGNORECASE
)
_PAGE_NUM_PATTERN = re.compile(r"^\s*\d{1,4}\s*$")


@dataclass
class RawPage:
    volume: int
    page: int
    chapter: str
    text: str


@dataclass
class Chunk:
    chunk_id: str
    volume: int
    page: int
    chapter: str
    heading: str | None
    text: str


def _infer_volume(filename: str) -> int:
    match = _VOLUME_PATTERN.search(filename)
    if match:
        return int(match.group(1))
    logger.warning("Could not infer volume number from filename: %s", filename)
    return 0


def _clean_lines(raw_lines: list[str], header_candidates: set[str]) -> list[str]:
    """Drop repeated headers/footers and bare page-number lines."""
    cleaned = []
    for line in raw_lines:
        stripped = line.strip()
        if not stripped:
            continue
        if _PAGE_NUM_PATTERN.match(stripped):
            continue
        if stripped in header_candidates:
            continue
        cleaned.append(stripped)
    return cleaned


def _detect_repeated_headers(pages_text: list[str], min_occurrences: int = 3) -> set[str]:
    """Find lines (e.g. running headers/footers) that repeat across many pages."""
    from collections import Counter

    counter: Counter[str] = Counter()
    for text in pages_text:
        first_last = [
            l.strip() for l in text.splitlines() if l.strip()
        ][:1] + [l.strip() for l in text.splitlines() if l.strip()][-1:]
        counter.update(first_last)
    return {line for line, count in counter.items() if count >= min_occurrences and len(line) < 80}


def extract_pages(pdf_path: Path) -> list[RawPage]:
    """Extract cleaned, chapter-tagged text for every page of a PDF."""
    volume = _infer_volume(pdf_path.name)
    doc = fitz.open(pdf_path)

    raw_texts = [page.get_text("text") for page in doc]
    header_candidates = _detect_repeated_headers(raw_texts)

    pages: list[RawPage] = []
    current_chapter = "Introduction"

    for page_number, raw_text in enumerate(raw_texts, start=1):
        lines = _clean_lines(raw_text.splitlines(), header_candidates)

        for line in lines:
            if _HEADING_PATTERN.match(line) and len(line) < 100:
                current_chapter = line.strip().title()
                break

        page_text = " ".join(lines).strip()
        # Collapse OCR/whitespace noise
        page_text = re.sub(r"\s{2,}", " ", page_text)
        page_text = re.sub(r"-\s+", "", page_text)  # de-hyphenate line breaks

        if page_text:
            pages.append(
                RawPage(volume=volume, page=page_number, chapter=current_chapter, text=page_text)
            )

    doc.close()
    return pages


def chunk_pages(
    pages: list[RawPage],
    chunk_size_tokens: int = 700,
    overlap_tokens: int = 120,
    encoding_name: str = "cl100k_base",
) -> list[Chunk]:
    """
    Merge page text into a running buffer per chapter and split into
    overlapping chunks of approximately `chunk_size_tokens` tokens.
    Each chunk keeps the page number where it starts, so citations stay
    accurate even when a ruling spans a page boundary.
    """
    enc = tiktoken.get_encoding(encoding_name)
    chunks: list[Chunk] = []

    buffer_tokens: list[int] = []
    buffer_start_page: int | None = None
    buffer_volume: int | None = None
    buffer_chapter: str | None = None

    def flush():
        if not buffer_tokens:
            return
        text = enc.decode(buffer_tokens)
        chunks.append(
            Chunk(
                chunk_id=str(uuid.uuid4()),
                volume=buffer_volume or 0,
                page=buffer_start_page or 0,
                chapter=buffer_chapter or "Unknown",
                heading=buffer_chapter,
                text=text.strip(),
            )
        )

    for page in pages:
        page_tokens = enc.encode(page.text)
        if buffer_chapter != page.chapter and buffer_tokens:
            flush()
            buffer_tokens = []

        if not buffer_tokens:
            buffer_start_page = page.page
            buffer_volume = page.volume
            buffer_chapter = page.chapter

        buffer_tokens.extend(page_tokens)

        while len(buffer_tokens) >= chunk_size_tokens:
            chunk_slice = buffer_tokens[:chunk_size_tokens]
            chunks.append(
                Chunk(
                    chunk_id=str(uuid.uuid4()),
                    volume=buffer_volume or 0,
                    page=buffer_start_page or 0,
                    chapter=buffer_chapter or "Unknown",
                    heading=buffer_chapter,
                    text=enc.decode(chunk_slice).strip(),
                )
            )
            # slide window forward, keeping overlap
            buffer_tokens = buffer_tokens[chunk_size_tokens - overlap_tokens :]
            buffer_start_page = page.page  # best-effort page tracking after slide

    flush()
    return [c for c in chunks if c.text]


def process_pdf(pdf_path: Path, chunk_size_tokens: int, overlap_tokens: int) -> list[Chunk]:
    """Full pipeline: extract -> clean -> chapterize -> chunk, for one PDF."""
    logger.info("Processing %s", pdf_path.name)
    pages = extract_pages(pdf_path)
    return chunk_pages(pages, chunk_size_tokens, overlap_tokens)
