"""
The RAG generation step: retrieve -> build prompt -> call the LLM
(streaming or non-streaming) -> return answer + the sources actually used.
"""
from __future__ import annotations

import logging
from collections.abc import AsyncIterator

from openai import AsyncOpenAI

from app.config import settings
from app.models import SourceChunk
from app.rag.prompt_builder import SYSTEM_PROMPT, build_user_prompt, is_effectively_not_found
from app.rag.retriever import retrieve

logger = logging.getLogger("noor_ai.chain")

_client = AsyncOpenAI(api_key=settings.openai_api_key)


async def answer_question(
    question: str,
    top_k: int | None = None,
    temperature: float | None = None,
    volume_filter: list[int] | None = None,
    chapter_filter: str | None = None,
) -> tuple[str, list[SourceChunk], bool]:
    """Non-streaming path used by POST /chat."""
    k = top_k or settings.default_top_k
    temp = temperature if temperature is not None else settings.default_temperature

    sources = retrieve(question, top_k=k, volume_filter=volume_filter, chapter_filter=chapter_filter)
    user_prompt = build_user_prompt(question, sources)

    response = await _client.chat.completions.create(
        model=settings.openai_chat_model,
        temperature=temp,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
    )
    answer = response.choices[0].message.content or ""
    grounded = not is_effectively_not_found(answer) and len(sources) > 0
    used_sources = sources if grounded else []
    return answer, used_sources, grounded


async def stream_answer(
    question: str,
    top_k: int | None = None,
    temperature: float | None = None,
    volume_filter: list[int] | None = None,
    chapter_filter: str | None = None,
) -> AsyncIterator[str]:
    """
    Streaming path used by POST /stream. Yields plain text deltas.
    The final chunk yielded is a special marker line the frontend parses to
    attach citation cards once the model has finished (see lib/api.ts).
    """
    k = top_k or settings.default_top_k
    temp = temperature if temperature is not None else settings.default_temperature

    sources = retrieve(question, top_k=k, volume_filter=volume_filter, chapter_filter=chapter_filter)
    user_prompt = build_user_prompt(question, sources)

    stream = await _client.chat.completions.create(
        model=settings.openai_chat_model,
        temperature=temp,
        stream=True,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_prompt},
        ],
    )

    full_answer = ""
    async for event in stream:
        delta = event.choices[0].delta.content or ""
        if delta:
            full_answer += delta
            yield delta

    grounded = not is_effectively_not_found(full_answer) and len(sources) > 0
    used_sources = sources if grounded else []
    import json

    yield "\n\n<<<NOOR_SOURCES>>>" + json.dumps(
        {"grounded": grounded, "sources": [s.model_dump() for s in used_sources]}
    )
