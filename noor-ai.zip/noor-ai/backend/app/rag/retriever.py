"""
Loads the persisted FAISS index and performs semantic search with
optional volume/chapter filtering.
"""
from __future__ import annotations

import logging
from pathlib import Path
from threading import Lock

from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings

from app.config import settings
from app.models import SourceChunk

logger = logging.getLogger("noor_ai.retriever")

_lock = Lock()
_vector_store: FAISS | None = None


def _get_embeddings() -> OpenAIEmbeddings:
    return OpenAIEmbeddings(
        model=settings.openai_embedding_model,
        api_key=settings.openai_api_key,
    )


def load_vector_store(force_reload: bool = False) -> FAISS | None:
    """Load the FAISS index from disk (cached in-process after first load)."""
    global _vector_store
    with _lock:
        if _vector_store is not None and not force_reload:
            return _vector_store

        index_dir = Path(settings.index_dir)
        if not (index_dir / "index.faiss").exists():
            logger.warning("No FAISS index found at %s. Run /reindex first.", index_dir)
            _vector_store = None
            return None

        _vector_store = FAISS.load_local(
            str(index_dir),
            _get_embeddings(),
            allow_dangerous_deserialization=True,
        )
        return _vector_store


def invalidate_cache() -> None:
    global _vector_store
    with _lock:
        _vector_store = None


def _passes_filters(
    doc: Document, volume_filter: list[int] | None, chapter_filter: str | None
) -> bool:
    if volume_filter and doc.metadata.get("volume") not in volume_filter:
        return False
    if chapter_filter and chapter_filter.lower() not in str(doc.metadata.get("chapter", "")).lower():
        return False
    return True


def retrieve(
    query: str,
    top_k: int = 6,
    volume_filter: list[int] | None = None,
    chapter_filter: str | None = None,
) -> list[SourceChunk]:
    """
    Run semantic search against the index and return the top_k matching
    chunks (post-filtered by volume/chapter if requested), each converted
    into a SourceChunk with a normalized similarity score.
    """
    store = load_vector_store()
    if store is None:
        return []

    # Over-fetch so filtering doesn't starve the result set.
    fetch_k = max(top_k * 4, 20)
    results = store.similarity_search_with_score(query, k=fetch_k)

    filtered: list[SourceChunk] = []
    for doc, distance in results:
        if not _passes_filters(doc, volume_filter, chapter_filter):
            continue
        # FAISS L2 distance -> similarity-ish score in (0, 1], higher is better.
        score = 1.0 / (1.0 + float(distance))
        filtered.append(
            SourceChunk(
                chunk_id=doc.metadata.get("chunk_id", ""),
                volume=int(doc.metadata.get("volume", 0)),
                page=int(doc.metadata.get("page", 0)),
                chapter=str(doc.metadata.get("chapter", "Unknown")),
                heading=doc.metadata.get("heading"),
                excerpt=doc.page_content[:600],
                score=round(score, 4),
            )
        )
        if len(filtered) >= top_k:
            break

    return filtered
