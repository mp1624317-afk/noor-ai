"""
Noor AI backend — FastAPI application.

Endpoints:
  GET  /            health check
  POST /chat        non-streaming RAG answer
  POST /stream      streaming RAG answer (text/event-stream style chunks)
  GET  /history      list saved conversations
  GET  /history/{id} fetch one conversation
  DELETE /history/{id} delete a conversation
  GET  /sources      list volumes/chapters currently indexed
  POST /reindex       rebuild the FAISS index from PDF_DIR
"""
from __future__ import annotations

import logging
import uuid

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse

from app.config import settings
from app.ingestion.build_index import build_and_save_index
from app.models import (
    ChatRequest,
    ChatResponse,
    Conversation,
    ReindexResponse,
    SourcesResponse,
)
from app.rag.chain import answer_question, stream_answer
from app.rag.retriever import invalidate_cache, load_vector_store
from app.storage import history

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("noor_ai")

app = FastAPI(title=settings.app_name, version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    return {"app": settings.app_name, "status": "ok"}


@app.post("/chat", response_model=ChatResponse)
async def chat(payload: ChatRequest):
    conversation_id = payload.conversation_id or str(uuid.uuid4())

    answer, sources, grounded = await answer_question(
        payload.message,
        top_k=payload.top_k,
        temperature=payload.temperature,
        volume_filter=payload.volume_filter,
        chapter_filter=payload.chapter_filter,
    )

    history.append_message(conversation_id, "user", payload.message, title_hint=payload.message)
    history.append_message(conversation_id, "assistant", answer, sources=sources)

    from datetime import datetime, timezone

    return ChatResponse(
        conversation_id=conversation_id,
        answer=answer,
        grounded=grounded,
        sources=sources,
        created_at=datetime.now(timezone.utc),
    )


@app.post("/stream")
async def stream(payload: ChatRequest):
    conversation_id = payload.conversation_id or str(uuid.uuid4())
    history.append_message(conversation_id, "user", payload.message, title_hint=payload.message)

    collected: list[str] = []

    async def event_generator():
        async for delta in stream_answer(
            payload.message,
            top_k=payload.top_k,
            temperature=payload.temperature,
            volume_filter=payload.volume_filter,
            chapter_filter=payload.chapter_filter,
        ):
            collected.append(delta)
            yield delta

        # Persist the full answer (minus the trailing metadata marker) once done.
        full_text = "".join(collected)
        answer_only = full_text.split("<<<NOOR_SOURCES>>>")[0].strip()
        history.append_message(conversation_id, "assistant", answer_only)

    return StreamingResponse(
        event_generator(),
        media_type="text/plain",
        headers={"X-Conversation-Id": conversation_id},
    )


@app.get("/history")
async def get_history() -> list[Conversation]:
    return history.list_conversations()


@app.get("/history/{conversation_id}", response_model=Conversation)
async def get_conversation(conversation_id: str):
    conversation = history.get_conversation(conversation_id)
    if conversation is None:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return conversation


@app.delete("/history/{conversation_id}")
async def delete_conversation(conversation_id: str):
    deleted = history.delete_conversation(conversation_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return {"status": "deleted"}


@app.get("/sources", response_model=SourcesResponse)
async def get_sources():
    store = load_vector_store()
    if store is None:
        return SourcesResponse(volumes=[], chapters=[], total_chunks=0)

    volumes: set[int] = set()
    chapters: set[str] = set()
    docstore = store.docstore._dict  # type: ignore[attr-defined]
    for doc in docstore.values():
        volumes.add(int(doc.metadata.get("volume", 0)))
        chapters.add(str(doc.metadata.get("chapter", "Unknown")))

    return SourcesResponse(
        volumes=sorted(volumes), chapters=sorted(chapters), total_chunks=len(docstore)
    )


@app.post("/reindex", response_model=ReindexResponse)
async def reindex():
    try:
        num_pdfs, num_chunks = build_and_save_index()
    except Exception as exc:  # noqa: BLE001
        logger.exception("Reindex failed")
        raise HTTPException(status_code=500, detail=f"Reindex failed: {exc}") from exc

    invalidate_cache()
    return ReindexResponse(
        status="ok" if num_chunks > 0 else "no_documents_found",
        documents_processed=num_pdfs,
        chunks_indexed=num_chunks,
    )
