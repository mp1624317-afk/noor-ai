"""
Central configuration for Noor AI backend.

All tunables (models, chunking, RAG defaults, paths) are loaded from
environment variables / .env so the app can be reconfigured without
touching code. See .env.example for the full list of options.
"""
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings, populated from environment variables."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # OpenAI
    openai_api_key: str
    openai_chat_model: str = "gpt-4.1"
    openai_embedding_model: str = "text-embedding-3-large"

    # App
    app_name: str = "Noor AI"
    environment: str = "development"
    cors_origins: str = "http://localhost:3000"

    # RAG
    chunk_size_tokens: int = 700
    chunk_overlap_tokens: int = 120
    default_top_k: int = 6
    default_temperature: float = 0.2

    # Paths
    pdf_dir: str = "./data/pdfs"
    index_dir: str = "./data/index"
    history_dir: str = "./data/history"

    @property
    def cors_origin_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

    @property
    def pdf_path(self) -> Path:
        p = Path(self.pdf_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def index_path(self) -> Path:
        p = Path(self.index_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p

    @property
    def history_path(self) -> Path:
        p = Path(self.history_dir)
        p.mkdir(parents=True, exist_ok=True)
        return p


settings = Settings()
