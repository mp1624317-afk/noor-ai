"""
Simple, dependency-free conversation history store.

Persists each conversation as a JSON file under HISTORY_DIR. This keeps the
project deployable without provisioning a database; swap this module for a
real DB-backed implementation later without touching the API layer, since
main.py only calls the functions defined here.
"""
from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

from app.config import settings
from app.models import ChatMessage, Conversation, SourceChunk


def _path_for(conversation_id: str) -> Path:
    return settings.history_path / f"{conversation_id}.json"


def create_conversation(title: str) -> Conversation:
    conversation = Conversation(
        conversation_id=str(uuid.uuid4()),
        title=title,
        messages=[],
        updated_at=datetime.now(timezone.utc),
    )
    _save(conversation)
    return conversation


def get_conversation(conversation_id: str) -> Conversation | None:
    path = _path_for(conversation_id)
    if not path.exists():
        return None
    data = json.loads(path.read_text(encoding="utf-8"))
    return Conversation.model_validate(data)


def append_message(
    conversation_id: str,
    role: str,
    content: str,
    sources: list[SourceChunk] | None = None,
    title_hint: str | None = None,
) -> Conversation:
    conversation = get_conversation(conversation_id)
    if conversation is None:
        conversation = Conversation(
            conversation_id=conversation_id,
            title=title_hint or content[:60],
            messages=[],
            updated_at=datetime.now(timezone.utc),
        )

    conversation.messages.append(
        ChatMessage(
            role=role,  # type: ignore[arg-type]
            content=content,
            sources=sources or [],
            created_at=datetime.now(timezone.utc),
        )
    )
    conversation.updated_at = datetime.now(timezone.utc)
    _save(conversation)
    return conversation


def list_conversations() -> list[Conversation]:
    conversations = []
    for path in settings.history_path.glob("*.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        conversations.append(Conversation.model_validate(data))
    return sorted(conversations, key=lambda c: c.updated_at, reverse=True)


def delete_conversation(conversation_id: str) -> bool:
    path = _path_for(conversation_id)
    if path.exists():
        path.unlink()
        return True
    return False


def _save(conversation: Conversation) -> None:
    path = _path_for(conversation.conversation_id)
    path.write_text(conversation.model_dump_json(indent=2), encoding="utf-8")
