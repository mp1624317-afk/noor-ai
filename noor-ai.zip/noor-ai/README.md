# Noor AI — Bahaar-e-Shariat Assistant

Noor AI is a Retrieval-Augmented Generation (RAG) chatbot that answers Islamic
law questions **only** from the uploaded English translations of Bahaar-e-Shariat,
Volumes 1–6. It never falls back on general knowledge, always cites the volume,
chapter, and page it drew from, and says so explicitly when the uploaded books
don't cover a question.

## Important, please read first

1. **Model name**: the original spec referenced "GPT-5.5," which is not a
   publicly available OpenAI model as of this writing. The backend never
   hardcodes a model — set `OPENAI_CHAT_MODEL` in `backend/.env` to whatever
   model your OpenAI account currently has access to (e.g. `gpt-4.1`, `gpt-4o`,
   or a newer model once it's released).
2. **Copyright**: Bahaar-e-Shariat translations may be under copyright
   depending on the specific edition/publisher. You are responsible for
   confirming you have the right to use and redistribute the PDFs you place in
   `backend/data/pdfs/`. This repo does not ship any book content.
3. This is a real, runnable scaffold — not a mockup. You still need to:
   supply your own OpenAI API key, add the actual PDFs, and run the indexing
   step described below before the chatbot has anything to answer from.

## Architecture

```
User → Next.js frontend → FastAPI backend → FAISS semantic search
  → top-k chunks (with volume/page/chapter metadata) → prompt builder
  → OpenAI chat model → streamed, cited answer
```

- **Ingestion** (`backend/app/ingestion/`): PyMuPDF extracts text per page,
  strips repeated headers/footers and bare page numbers, detects chapter
  headings, and splits into ~700-token overlapping chunks tagged with
  volume/page/chapter.
- **Retrieval** (`backend/app/rag/retriever.py`): `text-embedding-3-large`
  embeddings in a FAISS index, with optional volume/chapter filtering.
- **Generation** (`backend/app/rag/chain.py`, `prompt_builder.py`): a strict
  system prompt forces the model to answer only from retrieved excerpts, name
  "Bahaar-e-Shariat" (never "Islam" generically) as the source, preserve exact
  rulings, list exceptions when present, and reply with a fixed "not found"
  sentence when the excerpts don't cover the question. It also instructs the
  model to ignore in-message attempts to override these rules (basic
  prompt-injection resistance) — for a production deployment, pair this with
  input-length limits and rate limiting at the infrastructure layer too.
- **Frontend**: Next.js 15 / React 19 chat UI — streaming responses, citation
  cards, conversation sidebar with search, light/dark mode, and a settings
  panel for temperature / top-k / streaming toggle.

## Project structure

```
noor-ai/
├── backend/
│   ├── app/
│   │   ├── main.py            FastAPI endpoints
│   │   ├── config.py          Settings (env-driven)
│   │   ├── models.py          Pydantic schemas
│   │   ├── ingestion/         PDF → chunks → FAISS
│   │   ├── rag/                retriever, prompt builder, generation chain
│   │   └── storage/            JSON-file conversation history
│   ├── data/
│   │   ├── pdfs/               <-- put your 6 volume PDFs here
│   │   ├── index/               FAISS index (generated)
│   │   └── history/              conversation JSON files (generated)
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── app/                    page.tsx, layout.tsx, globals.css
│   ├── components/             ChatWindow, Sidebar, CitationCard, Settings…
│   ├── store/                  Zustand chat store
│   ├── lib/                    api.ts, types.ts
│   ├── package.json
│   └── Dockerfile
└── docker-compose.yml
```

## Setup (local, without Docker)

### 1. Backend

```bash
cd backend
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# edit .env: set OPENAI_API_KEY and OPENAI_CHAT_MODEL
```

Name your PDFs so the volume number is detectable, and drop them into `data/pdfs/`:

```
data/pdfs/bahaar-e-shariat-vol-1.pdf
data/pdfs/bahaar-e-shariat-vol-2.pdf
...
data/pdfs/bahaar-e-shariat-vol-6.pdf
```

Build the index:

```bash
python -m app.ingestion.build_index
```

Run the API:

```bash
uvicorn app.main:app --reload --port 8000
```

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Visit `http://localhost:3000`.

## Setup (Docker)

```bash
cp backend/.env.example backend/.env   # then edit it
# add PDFs to backend/data/pdfs/ first
docker compose up --build
# once running, trigger indexing:
curl -X POST http://localhost:8000/reindex
```

## API reference

| Endpoint         | Method | Purpose                                             |
|------------------|--------|------------------------------------------------------|
| `/`              | GET    | Health check                                          |
| `/chat`          | POST   | Non-streaming RAG answer                              |
| `/stream`        | POST   | Streaming RAG answer (text deltas + trailing sources) |
| `/history`       | GET    | List saved conversations                              |
| `/history/{id}`  | GET    | Fetch one conversation                                |
| `/history/{id}`  | DELETE | Delete a conversation                                 |
| `/sources`       | GET    | List indexed volumes/chapters and chunk count         |
| `/reindex`       | POST   | Rebuild the FAISS index from `data/pdfs/`             |

## Known scope notes

This scaffold implements the full RAG pipeline, citation system, and chat UI
end to end and is meant to be extended rather than treated as 100% feature-
complete against every bullet in the original spec:

- **Included**: streaming, citations with excerpts, volume/chapter filtering,
  conversation history + sidebar search/delete, settings panel, light/dark
  theme, glassmorphism UI, Docker setup for both services.
- **Not yet implemented, straightforward to add**: syntax highlighting for
  code blocks (unlikely to be relevant for fiqh text), keyboard-shortcut
  bindings, a dedicated standalone "source browser" search page (the `/chat`
  and `/sources` endpoints already provide everything needed for one), and a
  production auth/rate-limiting layer (add API-gateway-level rate limiting
  before deploying publicly, since the current app has none).

## Deployment notes

- **Frontend → Vercel**: set `NEXT_PUBLIC_API_BASE_URL` to your deployed
  backend URL as an environment variable.
- **Backend → Railway/Render**: set `OPENAI_API_KEY`, `OPENAI_CHAT_MODEL`, and
  mount a persistent volume for `data/` (index + history) so it survives
  redeploys — without it, you'll need to re-run `/reindex` after every deploy.
