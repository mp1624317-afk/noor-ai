import { create } from "zustand";
import type { ChatMessage, ChatSettings } from "@/lib/types";
import { sendChat, streamChat } from "@/lib/api";

interface ConversationSummary {
  conversation_id: string;
  title: string;
  updated_at: string;
}

interface ChatState {
  conversationId: string | null;
  messages: ChatMessage[];
  isLoading: boolean;
  settings: ChatSettings;
  sidebarConversations: ConversationSummary[];
  volumeFilter: number[] | null;
  chapterFilter: string | null;

  setSettings: (partial: Partial<ChatSettings>) => void;
  setFilters: (volume: number[] | null, chapter: string | null) => void;
  newConversation: () => void;
  setSidebarConversations: (list: ConversationSummary[]) => void;
  sendMessage: (text: string) => Promise<void>;
  regenerateLast: () => Promise<void>;
}

function makeId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

export const useChatStore = create<ChatState>((set, get) => ({
  conversationId: null,
  messages: [],
  isLoading: false,
  sidebarConversations: [],
  volumeFilter: null,
  chapterFilter: null,
  settings: {
    model: "default",
    temperature: 0.2,
    topK: 6,
    streaming: true,
    theme: "dark",
  },

  setSettings: (partial) => set((s) => ({ settings: { ...s.settings, ...partial } })),
  setFilters: (volume, chapter) => set({ volumeFilter: volume, chapterFilter: chapter }),
  setSidebarConversations: (list) => set({ sidebarConversations: list }),

  newConversation: () => set({ conversationId: null, messages: [] }),

  sendMessage: async (text: string) => {
    const { settings, conversationId, volumeFilter, chapterFilter } = get();
    const userMessage: ChatMessage = {
      id: makeId(),
      role: "user",
      content: text,
      sources: [],
      createdAt: new Date().toISOString(),
    };
    const assistantId = makeId();
    const assistantPlaceholder: ChatMessage = {
      id: assistantId,
      role: "assistant",
      content: "",
      sources: [],
      isStreaming: true,
      createdAt: new Date().toISOString(),
    };

    set((s) => ({ messages: [...s.messages, userMessage, assistantPlaceholder], isLoading: true }));

    const payload = {
      message: text,
      conversation_id: conversationId || undefined,
      top_k: settings.topK,
      temperature: settings.temperature,
      volume_filter: volumeFilter || undefined,
      chapter_filter: chapterFilter || undefined,
    };

    if (settings.streaming) {
      await streamChat(
        payload,
        (delta) => {
          set((s) => ({
            messages: s.messages.map((m) =>
              m.id === assistantId ? { ...m, content: m.content + delta } : m
            ),
          }));
        },
        ({ grounded, sources, conversationId: newId }) => {
          set((s) => ({
            conversationId: newId || s.conversationId,
            isLoading: false,
            messages: s.messages.map((m) =>
              m.id === assistantId ? { ...m, sources, grounded, isStreaming: false } : m
            ),
          }));
        },
        (err) => {
          set((s) => ({
            isLoading: false,
            messages: s.messages.map((m) =>
              m.id === assistantId
                ? { ...m, content: `Something went wrong: ${err.message}`, isStreaming: false }
                : m
            ),
          }));
        }
      );
    } else {
      try {
        const result = await sendChat(payload);
        set((s) => ({
          conversationId: result.conversation_id,
          isLoading: false,
          messages: s.messages.map((m) =>
            m.id === assistantId
              ? { ...m, content: result.answer, sources: result.sources, grounded: result.grounded, isStreaming: false }
              : m
          ),
        }));
      } catch (err) {
        set((s) => ({
          isLoading: false,
          messages: s.messages.map((m) =>
            m.id === assistantId
              ? { ...m, content: `Something went wrong: ${(err as Error).message}`, isStreaming: false }
              : m
          ),
        }));
      }
    }
  },

  regenerateLast: async () => {
    const { messages, sendMessage } = get();
    const lastUser = [...messages].reverse().find((m) => m.role === "user");
    if (!lastUser) return;
    set((s) => ({ messages: s.messages.slice(0, -2) }));
    await sendMessage(lastUser.content);
  },
}));
