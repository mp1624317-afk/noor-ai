"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Plus, Search, Trash2, Settings, Moon, Sun, BookMarked } from "lucide-react";
import clsx from "clsx";
import { useChatStore } from "@/store/useChatStore";
import { deleteConversation, fetchHistory } from "@/lib/api";

interface Props {
  onOpenSettings: () => void;
}

export function Sidebar({ onOpenSettings }: Props) {
  const {
    newConversation,
    conversationId,
    settings,
    setSettings,
    sidebarConversations,
    setSidebarConversations,
  } = useChatStore();
  const [query, setQuery] = useState("");

  useEffect(() => {
    fetchHistory()
      .then((list) =>
        setSidebarConversations(
          list.map((c: any) => ({
            conversation_id: c.conversation_id,
            title: c.title,
            updated_at: c.updated_at,
          }))
        )
      )
      .catch(() => {});
  }, [setSidebarConversations]);

  const filtered = sidebarConversations.filter((c) =>
    c.title.toLowerCase().includes(query.toLowerCase())
  );

  const toggleTheme = () => {
    const next = settings.theme === "dark" ? "light" : "dark";
    setSettings({ theme: next });
    document.documentElement.className = next;
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    await deleteConversation(id).catch(() => {});
    setSidebarConversations(sidebarConversations.filter((c) => c.conversation_id !== id));
  };

  return (
    <aside className="w-72 h-full glass-panel border-r border-gold-500/10 flex flex-col p-4 gap-4">
      <div className="flex items-center gap-2 px-1">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-gold-500 flex items-center justify-center">
          <BookMarked size={16} className="text-ink-900" />
        </div>
        <div>
          <p className="font-display text-lg leading-tight text-emerald-400">Noor AI</p>
          <p className="text-[10px] opacity-50 leading-tight">Bahaar-e-Shariat Assistant</p>
        </div>
      </div>

      <button
        onClick={newConversation}
        className="flex items-center gap-2 justify-center rounded-xl bg-emerald-600/90 hover:bg-emerald-600 text-white text-sm py-2.5 transition shadow-glass"
      >
        <Plus size={16} /> New chat
      </button>

      <div className="relative">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 opacity-50" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search chats"
          className="w-full bg-black/10 dark:bg-white/5 rounded-lg pl-8 pr-3 py-2 text-sm outline-none focus:ring-1 focus:ring-emerald-500/50"
        />
      </div>

      <div className="flex-1 overflow-y-auto flex flex-col gap-1">
        {filtered.map((c) => (
          <motion.div
            key={c.conversation_id}
            whileHover={{ x: 2 }}
            className={clsx(
              "group flex items-center justify-between rounded-lg px-3 py-2 text-sm cursor-pointer",
              conversationId === c.conversation_id ? "bg-emerald-600/20" : "hover:bg-white/5"
            )}
          >
            <span className="truncate">{c.title}</span>
            <button
              onClick={(e) => handleDelete(c.conversation_id, e)}
              className="opacity-0 group-hover:opacity-60 hover:!opacity-100 transition"
            >
              <Trash2 size={14} />
            </button>
          </motion.div>
        ))}
        {filtered.length === 0 && (
          <p className="text-xs opacity-40 text-center mt-6">No conversations yet</p>
        )}
      </div>

      <div className="flex items-center gap-2 border-t border-gold-500/10 pt-3">
        <button
          onClick={toggleTheme}
          className="flex-1 flex items-center gap-2 justify-center rounded-lg py-2 text-sm hover:bg-white/5 transition"
        >
          {settings.theme === "dark" ? <Sun size={14} /> : <Moon size={14} />}
          {settings.theme === "dark" ? "Light" : "Dark"}
        </button>
        <button
          onClick={onOpenSettings}
          className="flex-1 flex items-center gap-2 justify-center rounded-lg py-2 text-sm hover:bg-white/5 transition"
        >
          <Settings size={14} /> Settings
        </button>
      </div>
    </aside>
  );
}
