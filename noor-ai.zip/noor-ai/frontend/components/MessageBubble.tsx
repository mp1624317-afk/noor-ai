"use client";

import { motion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { Copy, RefreshCw, User, Sparkles, ShieldAlert } from "lucide-react";
import clsx from "clsx";
import type { ChatMessage } from "@/lib/types";
import { CitationRow } from "./CitationCard";
import { TypingIndicator } from "./TypingIndicator";

interface Props {
  message: ChatMessage;
  onRegenerate?: () => void;
}

export function MessageBubble({ message, onRegenerate }: Props) {
  const isUser = message.role === "user";
  const notFound =
    message.grounded === false &&
    message.content.toLowerCase().includes("do not contain a ruling");

  const copyText = () => navigator.clipboard.writeText(message.content);
  const time = new Date(message.createdAt).toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={clsx("flex gap-3 w-full", isUser ? "justify-end" : "justify-start")}
    >
      {!isUser && (
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-emerald-500 to-gold-500 flex items-center justify-center shrink-0 shadow-gold">
          <Sparkles size={16} className="text-ink-900" />
        </div>
      )}

      <div className={clsx("max-w-2xl", isUser && "order-first")}>
        <div
          className={clsx(
            "rounded-3xl px-5 py-4 shadow-glass",
            isUser
              ? "bg-emerald-600 text-white rounded-tr-md"
              : "glass-panel rounded-tl-md",
            notFound && "border border-gold-500/50"
          )}
        >
          {notFound && (
            <div className="flex items-center gap-2 text-gold-400 text-xs uppercase tracking-wide mb-2">
              <ShieldAlert size={14} /> Not covered in the uploaded volumes
            </div>
          )}

          {message.isStreaming && message.content.length === 0 ? (
            <TypingIndicator />
          ) : (
            <div className="markdown-body text-sm">
              <ReactMarkdown remarkPlugins={[remarkGfm]}>{message.content}</ReactMarkdown>
            </div>
          )}

          {!message.isStreaming && !isUser && <CitationRow sources={message.sources} />}
        </div>

        <div className={clsx("flex items-center gap-3 mt-1 text-[11px] opacity-50", isUser && "justify-end")}>
          <span>{time}</span>
          {!isUser && !message.isStreaming && (
            <>
              <button onClick={copyText} className="flex items-center gap-1 hover:text-emerald-400 transition">
                <Copy size={12} /> Copy
              </button>
              {onRegenerate && (
                <button onClick={onRegenerate} className="flex items-center gap-1 hover:text-emerald-400 transition">
                  <RefreshCw size={12} /> Regenerate
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {isUser && (
        <div className="w-9 h-9 rounded-full bg-ink-700 flex items-center justify-center shrink-0">
          <User size={16} className="text-emerald-400" />
        </div>
      )}
    </motion.div>
  );
}
