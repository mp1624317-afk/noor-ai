"use client";

import { motion } from "framer-motion";
import { BookOpen } from "lucide-react";
import type { SourceChunk } from "@/lib/types";

export function CitationCard({ source }: { source: SourceChunk }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-panel rounded-2xl p-4 shadow-glass hover:shadow-gold transition-shadow min-w-[240px] max-w-sm"
    >
      <div className="flex items-center gap-2 mb-2 text-gold-400">
        <BookOpen size={16} />
        <span className="text-xs font-semibold uppercase tracking-wide">
          Volume {source.volume} &middot; Page {source.page}
        </span>
      </div>
      <p className="text-sm font-medium text-emerald-400 mb-1">{source.chapter}</p>
      <p className="text-xs opacity-80 line-clamp-4">{source.excerpt}</p>
    </motion.div>
  );
}

export function CitationRow({ sources }: { sources: SourceChunk[] }) {
  if (!sources || sources.length === 0) return null;
  return (
    <div className="mt-3">
      <p className="text-xs uppercase tracking-wide opacity-60 mb-2">Sources</p>
      <div className="flex gap-3 overflow-x-auto pb-1">
        {sources.map((s) => (
          <CitationCard key={s.chunk_id} source={s} />
        ))}
      </div>
    </div>
  );
}
