"use client";

import { useEffect, useRef, useState } from "react";
import { Send, Sparkles } from "lucide-react";
import { useChatStore } from "@/store/useChatStore";
import { MessageBubble } from "./MessageBubble";

const SUGGESTIONS = [
  "What are the conditions that invalidate the fast in Ramadan?",
  "What does Bahaar-e-Shariat say about the Witr prayer?",
  "What is the ruling on combining prayers while traveling?",
];

export function ChatWindow() {
  const { messages, sendMessage, isLoading, regenerateLast } = useChatStore();
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = () => {
    const text = input.trim();
    if (!text || isLoading) return;
    setInput("");
    sendMessage(text);
  };

  return (
    <div className="flex-1 flex flex-col h-full">
      <div className="flex-1 overflow-y-auto px-6 py-8 space-y-6">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center gap-4 opacity-90">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-gold-500 flex items-center justify-center shadow-gold">
              <Sparkles size={28} className="text-ink-900" />
            </div>
            <div>
              <h1 className="font-display text-2xl text-emerald-400">Noor AI</h1>
              <p className="text-sm opacity-60 max-w-sm mx-auto mt-1">
                Ask about a ruling from Bahaar-e-Shariat, Volumes 1–6. Every answer
                is grounded in the uploaded text, with page-level citations.
              </p>
            </div>
            <div className="grid gap-2 mt-2 w-full max-w-md">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => sendMessage(s)}
                  className="glass-panel text-left text-sm rounded-xl px-4 py-3 hover:shadow-gold transition"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, idx) => (
          <MessageBubble
            key={m.id}
            message={m}
            onRegenerate={
              m.role === "assistant" && idx === messages.length - 1 ? regenerateLast : undefined
            }
          />
        ))}
        <div ref={bottomRef} />
      </div>

      <div className="p-4 border-t border-gold-500/10">
        <div className="glass-panel rounded-2xl flex items-end gap-2 p-2 shadow-glass">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            rows={1}
            placeholder="Ask a question about Bahaar-e-Shariat…"
            className="flex-1 bg-transparent outline-none resize-none px-3 py-2 text-sm max-h-32"
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !input.trim()}
            className="w-10 h-10 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 flex items-center justify-center transition shrink-0"
          >
            <Send size={16} className="text-white" />
          </button>
        </div>
        <p className="text-[11px] opacity-40 text-center mt-2">
          Noor AI answers only from the uploaded Bahaar-e-Shariat volumes and will say so when it can't find a ruling.
        </p>
      </div>
    </div>
  );
}
