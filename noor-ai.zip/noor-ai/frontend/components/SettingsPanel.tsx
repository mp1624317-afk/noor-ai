"use client";

import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { useChatStore } from "@/store/useChatStore";

export function SettingsPanel({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { settings, setSettings } = useChatStore();

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/40 z-40 flex items-center justify-center"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
            className="glass-panel rounded-2xl p-6 w-full max-w-md shadow-glass"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-lg text-emerald-400">Settings</h2>
              <button onClick={onClose}>
                <X size={18} />
              </button>
            </div>

            <div className="space-y-5 text-sm">
              <div>
                <label className="flex justify-between mb-1 opacity-80">
                  <span>Temperature</span>
                  <span>{settings.temperature.toFixed(2)}</span>
                </label>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={settings.temperature}
                  onChange={(e) => setSettings({ temperature: parseFloat(e.target.value) })}
                  className="w-full accent-emerald-500"
                />
                <p className="text-[11px] opacity-50 mt-1">
                  Lower keeps answers closer to the literal source wording.
                </p>
              </div>

              <div>
                <label className="flex justify-between mb-1 opacity-80">
                  <span>Chunks retrieved (top K)</span>
                  <span>{settings.topK}</span>
                </label>
                <input
                  type="range"
                  min={2}
                  max={12}
                  step={1}
                  value={settings.topK}
                  onChange={(e) => setSettings({ topK: parseInt(e.target.value) })}
                  className="w-full accent-gold-500"
                />
              </div>

              <div className="flex items-center justify-between">
                <span className="opacity-80">Stream responses</span>
                <button
                  onClick={() => setSettings({ streaming: !settings.streaming })}
                  className={`w-11 h-6 rounded-full transition relative ${
                    settings.streaming ? "bg-emerald-600" : "bg-gray-500/40"
                  }`}
                >
                  <span
                    className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition ${
                      settings.streaming ? "translate-x-5" : ""
                    }`}
                  />
                </button>
              </div>

              <p className="text-[11px] opacity-40 border-t border-gold-500/10 pt-3">
                Model is configured on the backend (OPENAI_CHAT_MODEL) so it can be
                upgraded without a frontend change.
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
