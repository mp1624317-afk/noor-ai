"use client";

import { useState } from "react";
import { Sidebar } from "@/components/Sidebar";
import { ChatWindow } from "@/components/ChatWindow";
import { SettingsPanel } from "@/components/SettingsPanel";

export default function HomePage() {
  const [settingsOpen, setSettingsOpen] = useState(false);

  return (
    <main className="flex h-screen w-full overflow-hidden">
      <Sidebar onOpenSettings={() => setSettingsOpen(true)} />
      <ChatWindow />
      <SettingsPanel open={settingsOpen} onClose={() => setSettingsOpen(false)} />
    </main>
  );
}
