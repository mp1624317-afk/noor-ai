import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Noor AI — Bahaar-e-Shariat Assistant",
  description:
    "Ask questions and get clear, cited explanations of Islamic rulings from Bahaar-e-Shariat, Volumes 1-6.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
