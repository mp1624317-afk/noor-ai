import type { SourceChunk } from "./types";

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000";

export interface ChatPayload {
  message: string;
  conversation_id?: string;
  top_k?: number;
  temperature?: number;
  volume_filter?: number[];
  chapter_filter?: string;
}

export interface ChatResult {
  conversation_id: string;
  answer: string;
  grounded: boolean;
  sources: SourceChunk[];
}

/** Non-streaming chat call. */
export async function sendChat(payload: ChatPayload): Promise<ChatResult> {
  const res = await fetch(`${API_BASE}/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error(`Chat request failed: ${res.status}`);
  return res.json();
}

/**
 * Streaming chat call. Calls `onDelta` for every text chunk as it arrives,
 * and `onDone` once the stream ends with the parsed sources/grounded flag
 * (extracted from the trailing <<<NOOR_SOURCES>>> marker the backend appends).
 */
export async function streamChat(
  payload: ChatPayload,
  onDelta: (text: string) => void,
  onDone: (result: { grounded: boolean; sources: SourceChunk[]; conversationId: string | null }) => void,
  onError: (err: Error) => void
): Promise<void> {
  try {
    const res = await fetch(`${API_BASE}/stream`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok || !res.body) throw new Error(`Stream request failed: ${res.status}`);

    const conversationId = res.headers.get("X-Conversation-Id");
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    const MARKER = "<<<NOOR_SOURCES>>>";

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      if (buffer.includes(MARKER)) {
        const [textPart] = buffer.split(MARKER);
        onDelta(textPart);
        buffer = buffer.slice(textPart.length);
      } else {
        onDelta(buffer);
        buffer = "";
      }
    }

    let grounded = false;
    let sources: SourceChunk[] = [];
    if (buffer.includes(MARKER)) {
      const jsonPart = buffer.split(MARKER)[1];
      try {
        const parsed = JSON.parse(jsonPart);
        grounded = parsed.grounded;
        sources = parsed.sources;
      } catch {
        // ignore malformed trailing metadata
      }
    }

    onDone({ grounded, sources, conversationId });
  } catch (err) {
    onError(err as Error);
  }
}

export async function fetchHistory() {
  const res = await fetch(`${API_BASE}/history`);
  if (!res.ok) throw new Error("Failed to fetch history");
  return res.json();
}

export async function deleteConversation(conversationId: string) {
  const res = await fetch(`${API_BASE}/history/${conversationId}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Failed to delete conversation");
  return res.json();
}

export async function fetchSources() {
  const res = await fetch(`${API_BASE}/sources`);
  if (!res.ok) throw new Error("Failed to fetch sources");
  return res.json();
}

export async function triggerReindex() {
  const res = await fetch(`${API_BASE}/reindex`, { method: "POST" });
  if (!res.ok) throw new Error("Reindex failed");
  return res.json();
}
