export interface SourceChunk {
  chunk_id: string;
  volume: number;
  page: number;
  chapter: string;
  heading?: string | null;
  excerpt: string;
  score: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  sources: SourceChunk[];
  grounded?: boolean;
  createdAt: string;
  isStreaming?: boolean;
}

export interface Conversation {
  conversation_id: string;
  title: string;
  messages: ChatMessage[];
  updated_at: string;
}

export interface ChatSettings {
  model: string;
  temperature: number;
  topK: number;
  streaming: boolean;
  theme: "light" | "dark";
}
